@start explorer %APPDATA%\Teeworlds
